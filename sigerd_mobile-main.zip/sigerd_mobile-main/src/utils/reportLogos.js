
export const LOGO_DEFESA_CIVIL = '/logo_defesa_civil.png';
export const LOGO_SIGERD = '/logo_sigerd.png';

import React, { useState, useEffect, useContext } from 'react'
import { Save, Camera, FileText, MapPin, Trash2, Share, ArrowLeft, Crosshair, ShieldAlert, AlertOctagon, User, Upload, X, Edit2, Sparkles, Siren } from 'lucide-react'
import { checkRiskArea } from '../../services/riskAreas'
import { saveInterdicaoOffline } from '../../services/db'
import FileInput from '../../components/FileInput'
import { generatePDF } from '../../utils/pdfGenerator'
import { compressImage } from '../../utils/imageOptimizer'
import SignaturePadComp from '../../components/SignaturePad'
import VoiceInput from '../../components/VoiceInput'
import { supabase } from '../../services/supabase'
import { UserContext } from '../../App'
import bairrosData from '../../../Bairros.json'
import logradourosData from '../../../Logradouros.json'

const InterdicaoForm = ({ onBack, initialData = null }) => {
    const userProfile = useContext(UserContext)
    const [formData, setFormData] = useState({
        interdicaoId: '',
        dataHora: (() => {
            const now = new Date();
            const brasiliaTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' }));
            const year = brasiliaTime.getFullYear();
            const month = String(brasiliaTime.getMonth() + 1).padStart(2, '0');
            const day = String(brasiliaTime.getDate()).padStart(2, '0');
            const hours = String(brasiliaTime.getHours()).padStart(2, '0');
            const minutes = String(brasiliaTime.getMinutes()).padStart(2, '0');
            return `${year}-${month}-${day}T${hours}:${minutes}`;
        })(),
        municipio: 'Santa Maria de Jetibá',
        bairro: '',
        endereco: '',
        tipoAlvo: 'Imóvel',
        tipoAlvoEspecificar: '',
        latitude: '',
        longitude: '',
        coordenadas: '',
        responsavelNome: '',
        responsavelCpf: '',
        responsavelTelefone: '',
        responsavelEmail: '',
        riscoTipo: [],
        riscoGrau: 'Médio',
        situacaoObservada: '',
        medidaTipo: 'Total',
        medidaPrazo: 'Indeterminado',
        medidaPrazoData: '',
        evacuacaoNecessaria: false,
        fotos: [],
        relatorioTecnico: '',
        recomendacoes: '',
        orgaosAcionados: '',
        agente: userProfile?.full_name || '',
        matricula: userProfile?.matricula || '',
        assinaturaAgente: null,
        apoioTecnico: { nome: '', crea: '', matricula: '', assinatura: null }
    })

    const [showSignaturePad, setShowSignaturePad] = useState(false)

    const [saving, setSaving] = useState(false)
    const [gettingLoc, setGettingLoc] = useState(false)
    const [activeSignatureType, setActiveSignatureType] = useState('agente') // 'agente' or 'apoio'
    const [detectedRiskArea, setDetectedRiskArea] = useState(null)
    const [refining, setRefining] = useState(false)

    useEffect(() => {
        if (initialData) {
            // Map DB fields back to form state if necessary
            // For interdicao, the fields seem to match mostly, but let's be careful
            setFormData({
                ...initialData,
                interdicaoId: initialData.interdicao_id || initialData.interdicaoId,
                dataHora: initialData.data_hora || initialData.dataHora,
                tipoAlvo: initialData.tipo_alvo || initialData.tipoAlvo,
                tipoAlvoEspecificar: initialData.tipo_alvo_especificar || initialData.tipoAlvoEspecificar,
                responsavelNome: initialData.responsavel_nome || initialData.responsavelNome,
                responsavelCpf: initialData.responsavel_cpf || initialData.responsavelCpf,
                responsavelTelefone: initialData.responsavel_telefone || initialData.responsavelTelefone,
                responsavelEmail: initialData.responsavel_email || initialData.responsavelEmail,
                riscoTipo: initialData.risco_tipo || initialData.riscoTipo || [],
                riscoGrau: initialData.risco_grau || initialData.riscoGrau,
                situacaoObservada: initialData.situacao_observada || initialData.situacaoObservada,
                medidaTipo: initialData.medida_tipo || initialData.medidaTipo,
                medidaPrazo: initialData.medida_prazo || initialData.medidaPrazo,
                medidaPrazoData: initialData.medida_prazo_data || initialData.medidaPrazoData,
                evacuacaoNecessaria: initialData.evacuacao_necessaria ?? initialData.evacuacaoNecessaria,
                relatorioTecnico: initialData.relatorio_tecnico || initialData.relatorioTecnico,
                recomendacoes: initialData.recomendacoes,
                orgaosAcionados: initialData.orgaos_acionados || initialData.orgaosAcionados,
                agente: initialData.agente || initialData.agente || '',
                matricula: initialData.matricula || initialData.matricula || '',
                assinaturaAgente: initialData.assinatura_agente || initialData.assinaturaAgente || null,
                apoioTecnico: initialData.apoio_tecnico || initialData.apoioTecnico || { nome: '', crea: '', matricula: '', assinatura: null },
                fotos: (initialData.fotos || []).map((f, i) =>
                    typeof f === 'string'
                        ? { id: `legacy-${i}`, data: f, legenda: '' }
                        : { ...f, id: f.id || `photo-${i}`, legenda: f.legenda || '' }
                )
            })

            // Check Risk Area on Load
            if (initialData.latitude && initialData.longitude) {
                const riskInfo = checkRiskArea(initialData.latitude, initialData.longitude);
                setDetectedRiskArea(riskInfo);
            }
        } else {
            getNextId()
        }
    }, [initialData])

    // Listen for deletion events to recalculate ID
    useEffect(() => {
        const handleDeletion = () => {
            if (!initialData) {
                getNextId()
            }
        }
        window.addEventListener('interdicao-deleted', handleDeletion)
        return () => window.removeEventListener('interdicao-deleted', handleDeletion)
    }, [initialData])

    const getLocation = () => {
        if (!navigator.geolocation) {
            alert("GPS não suportado neste dispositivo.")
            return
        }

        setGettingLoc(true)
        navigator.geolocation.getCurrentPosition(
            (pos) => {
                const { latitude, longitude } = pos.coords
                setFormData(prev => ({
                    ...prev,
                    latitude: latitude,
                    longitude: longitude,
                    coordenadas: `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`
                }))

                // Check Risk Area
                const riskInfo = checkRiskArea(latitude, longitude);
                setDetectedRiskArea(riskInfo);

                if (riskInfo) {
                    alert(`⚠️ ALERTA: Esta localidade está em uma Área de Risco Mapeada!\n\nLocal: ${riskInfo.name}\nFonte: ${riskInfo.source}`);

                    // Auto-append to technical report if not already there
                    setFormData(prev => {
                        const riskNote = `[SISTEMA] Interdição realizada em área de risco mapeada: ${riskInfo.name} (${riskInfo.source}).`;
                        if (!prev.relatorioTecnico.includes(riskNote)) {
                            return {
                                ...prev,
                                relatorioTecnico: riskNote + (prev.relatorioTecnico ? '\n\n' + prev.relatorioTecnico : '')
                            }
                        }
                        return prev;
                    });
                }

                setGettingLoc(false)
                if (!riskInfo) alert("Coordenadas atualizadas com sucesso!")
            },
            (err) => {
                console.error("Erro GPS:", err)
                setGettingLoc(false)
                alert("Erro ao obter localização. Verifique se o GPS está ativado.")
            },
            { enableHighAccuracy: true, timeout: 10000 }
        )
    }

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }))
    }

    const handleAIRefine = async () => {
        if (!formData.situacaoObservada.trim()) return alert("Digite algo na situação observada primeiro.");
        setRefining(true);
        try {
            const { data, error } = await supabase.functions.invoke('refine-report', {
                body: {
                    text: formData.situacaoObservada,
                    category: formData.riscoTipo.join(', '),
                    context: `Local: ${formData.endereco}, Alvo: ${formData.tipoAlvo}`
                }
            });

            if (error || (data && data.error)) {
                throw new Error(data?.error || error?.message || "Serviço de IA indisponível no momento.");
            }
            if (data.refinedText) {
                if (window.confirm("A IA refinou o seu texto. Deseja substituir o original pelo texto técnico profissional?")) {
                    setFormData(prev => ({ ...prev, situacaoObservada: data.refinedText }));
                }
            }
        } catch (e) {
            console.error("AI Refine error:", e);
            alert(`Erro ao refinar com IA: ${e.message}`);
        } finally {
            setRefining(false);
        }
    }

    const toggleRisco = (tipo) => {
        setFormData(prev => ({
            ...prev,
            riscoTipo: prev.riscoTipo.includes(tipo)
                ? prev.riscoTipo.filter(t => t !== tipo)
                : [...prev.riscoTipo, tipo]
        }))
    }

    const handlePhotoSelect = async (files) => {
        const newPhotos = await Promise.all(files.map(file => {
            return new Promise((resolve) => {
                const reader = new FileReader()
                reader.onloadend = async () => {
                    try {
                        const coords = formData.latitude && formData.longitude ? {
                            lat: formData.latitude,
                            lng: formData.longitude
                        } : null;

                        const compressed = await compressImage(reader.result, { coordinates: coords });
                        resolve({
                            id: Date.now() + Math.random(),
                            data: compressed,
                            legenda: ''
                        })
                    } catch (e) {
                        console.error("Compression error:", e)
                        resolve({
                            id: Date.now() + Math.random(),
                            data: reader.result,
                            legenda: ''
                        })
                    }
                }
                reader.readAsDataURL(file)
            })
        }))
        setFormData(prev => ({ ...prev, fotos: [...prev.fotos, ...newPhotos] }))
    }

    const removePhoto = (id) => {
        setFormData(prev => ({ ...prev, fotos: prev.fotos.filter(p => p.id !== id) }))
    }

    const getNextId = async () => {
        const currentYear = new Date().getFullYear()

        if (!navigator.onLine) {
            setFormData(prev => ({ ...prev, interdicaoId: '' }))
            return
        }

        try {
            const { data } = await supabase
                .from('interdicoes')
                .select('interdicao_id')
                .filter('interdicao_id', 'like', `%/${currentYear}`)

            let maxNum = 0
            if (data && data.length > 0) {
                data.forEach(v => {
                    const parts = (v.interdicao_id || '').split('/')
                    const n = parseInt(parts[0])
                    if (!isNaN(n)) maxNum = Math.max(maxNum, n)
                })
            }

            const formattedId = `${(maxNum + 1).toString().padStart(2, '0')}/${currentYear}`
            setFormData(prev => ({ ...prev, interdicaoId: formattedId }))
        } catch (e) {
            console.error(e)
            setFormData(prev => ({ ...prev, interdicaoId: '' }))
        }
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        setSaving(true)
        try {
            await saveInterdicaoOffline(formData)
            alert('Interdição salva com sucesso!')
            onBack()
        } catch (error) {
            console.error(error)
            alert('Erro ao salvar interdição.')
        } finally {
            setSaving(false)
        }
    }

    // Styles
    const inputClasses = "w-full bg-slate-50 p-3.5 rounded-xl border border-gray-200 outline-none focus:border-[#2a5299] focus:ring-2 focus:ring-[#2a5299]/20 transition-all text-gray-700 font-medium placeholder:text-gray-400"
    const labelClasses = "text-sm text-[#2a5299] font-bold block mb-1.5 uppercase tracking-wide opacity-90"
    const sectionClasses = "bg-white p-5 rounded-2xl shadow-sm border border-gray-100 space-y-5"

    return (
        <div className="bg-slate-50 min-h-screen pb-32 font-sans">
            {/* Header */}
            <div className="bg-white px-5 py-4 shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07)] sticky top-0 z-10 border-b border-gray-100 flex items-center gap-3">
                <button onClick={onBack} className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full">
                    <ArrowLeft size={24} />
                </button>
                <h1 className="text-2xl font-black text-gray-800 tracking-tight">
                    {initialData ? (formData.interdicaoId || 'Interdição') : 'Nova Interdição'}
                </h1>
            </div>

            {detectedRiskArea && (
                <div className="bg-red-50 mx-5 mt-5 mb-0 p-4 rounded-xl border-l-4 border-red-500 shadow-sm flex items-start gap-3 animate-in fade-in slide-in-from-top-4">
                    <div className="bg-red-100 p-2 rounded-full">
                        <Siren className="text-red-600 animate-pulse" size={24} />
                    </div>
                    <div>
                        <h3 className="font-extrabold text-red-700 uppercase tracking-wide text-sm">Área de Risco Detectada</h3>
                        <p className="text-red-600 font-bold leading-tight mt-1">{detectedRiskArea.name}</p>
                        <p className="text-red-500 text-xs mt-1 font-medium">Fonte: {detectedRiskArea.source}</p>
                    </div>
                </div>
            )}

            <form onSubmit={handleSubmit} className="p-5 space-y-6 max-w-xl mx-auto">

                {/* 1. Identificação */}
                <section className={sectionClasses}>
                    <h2 className="font-bold text-gray-800 text-lg border-b border-gray-100 pb-3 mb-2 flex items-center gap-2">
                        <span className="w-1 h-6 bg-[#2a5299] rounded-full"></span>
                        1. Identificação
                    </h2>

                    <div className="grid grid-cols-2 gap-5">
                        <div className="col-span-2">
                            <label className={labelClasses}>Nº Interdição</label>
                            <div className={`text-lg font-black p-3.5 rounded-xl border flex justify-between items-center shadow-inner ${formData.interdicaoId ? 'bg-blue-50/50 text-[#2a5299] border-blue-100/50' : 'bg-orange-50/50 text-orange-600 border-orange-100/50 italic text-base'}`}>
                                {formData.interdicaoId || 'Pendente (Gerado no Sincronismo)'}
                            </div>
                        </div>
                        <div className="col-span-2">
                            <label className={labelClasses}>Data e Hora</label>
                            <input type="datetime-local" value={formData.dataHora} onChange={e => handleChange('dataHora', e.target.value)} className={inputClasses} />
                        </div>
                        <div>
                            <label className={labelClasses}>Município</label>
                            <input type="text" value={formData.municipio} readOnly className={`${inputClasses} bg-gray-100 text-gray-500`} />
                        </div>
                        <div>
                            <label className={labelClasses}>Bairro / Localidade</label>
                            <input
                                type="text"
                                list="bairros-list"
                                value={formData.bairro}
                                onChange={e => handleChange('bairro', e.target.value)}
                                className={inputClasses}
                                required
                                placeholder="Digite ou selecione..."
                            />
                            <datalist id="bairros-list">
                                {bairrosData.map(b => b.nome).sort().map(nome => (
                                    <option key={nome} value={nome} />
                                ))}
                            </datalist>
                        </div>
                        <div className="col-span-2">
                            <label className={labelClasses}>Endereço Completo</label>
                            <input
                                type="text"
                                list="logradouros-interdicao-list"
                                value={formData.endereco}
                                onChange={e => handleChange('endereco', e.target.value)}
                                className={inputClasses}
                                required
                                placeholder="Rua, número, ponto de referência..."
                            />
                            <datalist id="logradouros-interdicao-list">
                                {logradourosData.map(l => l.nome).sort().map(nome => (
                                    <option key={nome} value={nome} />
                                ))}
                            </datalist>
                        </div>
                    </div>

                    <div>
                        <label className={labelClasses}>Tipo de Alvo</label>
                        <div className="grid grid-cols-2 gap-2">
                            {['Imóvel', 'Via pública', 'Área pública', 'Outro'].map(t => (
                                <button key={t} type="button" onClick={() => handleChange('tipoAlvo', t)} className={`p-3 rounded-xl text-xs font-bold border transition-all ${formData.tipoAlvo === t ? 'bg-[#2a5299] border-[#2a5299] text-white shadow-md' : 'bg-white border-slate-100 text-slate-500'}`}>
                                    {t}
                                </button>
                            ))}
                        </div>
                        {formData.tipoAlvo === 'Outro' && (
                            <input type="text" placeholder="Especifique..." value={formData.tipoAlvoEspecificar} onChange={e => handleChange('tipoAlvoEspecificar', e.target.value)} className={`${inputClasses} mt-2 animate-in slide-in-from-top-2 duration-300`} />
                        )}
                    </div>
                </section>

                {/* 2. Geolocalização */}
                <section className={sectionClasses}>
                    <h2 className="font-bold text-gray-800 text-lg border-b border-gray-100 pb-3 mb-2 flex items-center gap-2">
                        <span className="w-1 h-6 bg-[#2a5299] rounded-full"></span>
                        2. Localização
                    </h2>
                    <div className="flex gap-2">
                        <div className="relative flex-1">
                            <MapPin size={20} className="absolute left-4 top-4 text-[#2a5299]" />
                            <input
                                type="text"
                                className={`${inputClasses} pl-12 bg-gray-100 text-gray-500`}
                                value={formData.coordenadas}
                                readOnly
                                placeholder="Lat, Long"
                            />
                        </div>
                        <button
                            type="button"
                            onClick={getLocation}
                            className={`p-3.5 rounded-xl shadow-lg active:scale-95 transition-all text-white flex items-center justify-center gap-2 ${gettingLoc ? 'bg-gray-400' : 'bg-[#2a5299] hover:bg-[#1e3c72]'}`}
                            disabled={gettingLoc}
                        >
                            <Crosshair size={24} className={gettingLoc ? 'animate-spin' : ''} />
                            {gettingLoc ? 'Buscando...' : ''}
                        </button>
                    </div>
                </section>

                {/* 3. Identificação do Responsável */}
                {formData.tipoAlvo !== 'Via pública' && (
                    <section className={`${sectionClasses} animate-in fade-in duration-500`}>
                        <h2 className="font-bold text-gray-800 text-lg border-b border-gray-100 pb-3 mb-2 flex items-center gap-2">
                            <span className="w-1 h-6 bg-[#2a5299] rounded-full"></span>
                            3. Responsável / Proprietário
                        </h2>

                        <div className="space-y-4">
                            <div>
                                <label className={labelClasses}>Nome Completo</label>
                                <input type="text" value={formData.responsavelNome} onChange={e => handleChange('responsavelNome', e.target.value)} className={inputClasses} />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className={labelClasses}>CPF/CNPJ</label>
                                    <input type="tel" inputMode="numeric" pattern="[0-9]*" value={formData.responsavelCpf} onChange={e => handleChange('responsavelCpf', e.target.value.replace(/\D/g, ''))} className={inputClasses} />
                                </div>
                                <div>
                                    <label className={labelClasses}>Telefone</label>
                                    <input type="tel" inputMode="tel" value={formData.responsavelTelefone} onChange={e => handleChange('responsavelTelefone', e.target.value)} className={inputClasses} />
                                </div>
                            </div>
                            <div>
                                <label className={labelClasses}>E-mail</label>
                                <input type="email" value={formData.responsavelEmail} onChange={e => handleChange('responsavelEmail', e.target.value)} className={inputClasses} />
                            </div>
                        </div>
                    </section>
                )}

                {/* 4. Caracterização do Risco */}
                <section className={sectionClasses}>
                    <h2 className="font-bold text-gray-800 text-lg border-b border-gray-100 pb-3 mb-2 flex items-center gap-2">
                        <span className="w-1 h-6 bg-[#2a5299] rounded-full"></span>
                        4. Caracterização do Risco
                    </h2>

                    <div>
                        <label className={labelClasses}>Tipo de Ocorrência (Múltiplo)</label>
                        <div className="flex flex-wrap gap-2">
                            {['Risco estrutural', 'Deslizamento', 'Alagamento', 'Erosão', 'Incêndio', 'Colapso parcial', 'Colapso total', 'Outro'].map(r => (
                                <button key={r} type="button" onClick={() => toggleRisco(r)} className={`px-4 py-2 rounded-full text-xs font-bold border transition-all ${formData.riscoTipo.includes(r) ? 'bg-red-600 border-red-600 text-white shadow-sm' : 'bg-slate-50 border-slate-100 text-slate-400'}`}>
                                    {r}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <label className={labelClasses}>Grau de Risco</label>
                        <div className="grid grid-cols-4 gap-2">
                            {['Baixo', 'Médio', 'Alto', 'Imediato'].map(g => (
                                <button key={g} type="button" onClick={() => handleChange('riscoGrau', g)} className={`py-3 rounded-xl text-[10px] font-black uppercase transition-all border ${formData.riscoGrau === g ? 'bg-slate-800 border-slate-800 text-white' : 'bg-white border-slate-100 text-slate-400'}`}>
                                    {g}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <div className="flex justify-between items-center mb-1.5">
                            <label className={labelClasses} style={{ marginBottom: 0 }}>Situação Observada</label>
                            <button
                                type="button"
                                onClick={handleAIRefine}
                                disabled={refining}
                                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all shadow-sm ${refining ? 'bg-slate-100 text-slate-400 animate-pulse' : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:shadow-md active:scale-95'}`}
                            >
                                <Sparkles size={12} className={refining ? 'animate-spin' : ''} />
                                {refining ? 'Refinando...' : 'Refinar com IA'}
                            </button>
                        </div>
                        <textarea
                            rows="3"
                            value={formData.situacaoObservada}
                            onChange={e => handleChange('situacaoObservada', e.target.value)}
                            className={`${inputClasses} ${refining ? 'opacity-50' : ''}`}
                            placeholder="Descreva os danos e evidências..."
                        />
                    </div>
                </section>

                {/* 5. Medida Administrativa */}
                <section className={sectionClasses}>
                    <h2 className="font-bold text-gray-800 text-lg border-b border-gray-100 pb-3 mb-2 flex items-center gap-2">
                        <span className="w-1 h-6 bg-[#2a5299] rounded-full"></span>
                        5. Medida Administrativa
                    </h2>

                    <div>
                        <label className={labelClasses}>Tipo de Interdição</label>
                        <div className="grid grid-cols-3 gap-2">
                            {['Total', 'Parcial', 'Preventiva'].map(m => (
                                <button key={m} type="button" onClick={() => handleChange('medidaTipo', m)} className={`p-3 rounded-xl text-xs font-bold border transition-all ${formData.medidaTipo === m ? 'bg-amber-500 border-amber-500 text-white shadow-md' : 'bg-white border-slate-100 text-slate-500'}`}>
                                    {m}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className={labelClasses}>Prazo</label>
                            <select value={formData.medidaPrazo} onChange={e => handleChange('medidaPrazo', e.target.value)} className={inputClasses}>
                                <option>Indeterminado</option>
                                <option>Determinado</option>
                            </select>
                        </div>
                        {formData.medidaPrazo === 'Determinado' && (
                            <div className="animate-in slide-in-from-right-2 duration-300">
                                <label className={labelClasses}>Data Final</label>
                                <input type="date" value={formData.medidaPrazoData} onChange={e => handleChange('medidaPrazoData', e.target.value)} className={inputClasses} />
                            </div>
                        )}
                    </div>

                    <div className="flex items-center justify-between p-4 bg-red-50 rounded-2xl border border-red-100">
                        <div>
                            <div className="text-xs font-black text-red-600 uppercase tracking-widest">Evacuação</div>
                            <div className="text-[10px] font-bold text-red-400">Desocupação imediata?</div>
                        </div>
                        <div className="flex bg-white p-1 rounded-xl shadow-inner border border-red-100">
                            <button type="button" onClick={() => handleChange('evacuacaoNecessaria', true)} className={`px-4 py-1.5 rounded-lg text-xs font-black transition-all ${formData.evacuacaoNecessaria ? 'bg-red-600 text-white shadow-md' : 'text-slate-400'}`}>SIM</button>
                            <button type="button" onClick={() => handleChange('evacuacaoNecessaria', false)} className={`px-4 py-1.5 rounded-lg text-xs font-black transition-all ${!formData.evacuacaoNecessaria ? 'bg-slate-100 text-slate-600' : 'text-slate-400'}`}>NÃO</button>
                        </div>
                    </div>
                </section>

                {/* 6. Registro Fotográfico */}
                <section className={sectionClasses}>
                    <div className="flex justify-between items-center border-b border-gray-100 pb-3 mb-2">
                        <h2 className="font-bold text-gray-800 text-lg flex items-center gap-2">
                            <span className="w-1 h-6 bg-[#2a5299] rounded-full"></span>
                            6. Registro Fotográfico
                        </h2>
                        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">{formData.fotos.length} fotos</span>
                    </div>

                    <div className="grid grid-cols-4 gap-3 justify-items-center">
                        <FileInput onFileSelect={handlePhotoSelect} label="+" />
                        {formData.fotos.map((foto, idx) => (
                            <div key={foto.id} className="relative w-full aspect-square rounded-xl overflow-hidden shadow-md group">
                                <img src={foto.data || foto} className="w-full h-full object-cover" alt="Preview" />
                                <button type="button" onClick={() => removePhoto(foto.id)} className="absolute top-1 right-1 bg-white/80 p-1 rounded-full text-red-500 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity">
                                    <X size={12} />
                                </button>
                                <div className="absolute bottom-0 left-0 right-0 p-1 bg-black/40">
                                    <input
                                        type="text"
                                        placeholder="Legenda..."
                                        className="w-full bg-transparent text-[8px] text-white border-none p-0 focus:ring-0 placeholder:text-white/60"
                                        value={foto.legenda}
                                        onChange={e => {
                                            const newFotos = [...formData.fotos]
                                            newFotos[idx].legenda = e.target.value
                                            handleChange('fotos', newFotos)
                                        }}
                                    />
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

                {/* 7. Observações Técnicas */}
                <section className={sectionClasses}>
                    <h2 className="font-bold text-gray-800 text-lg border-b border-gray-100 pb-3 mb-2 flex items-center gap-2">
                        <span className="w-1 h-6 bg-[#2a5299] rounded-full"></span>
                        7. Relatório e Recomendações
                    </h2>

                    <div>
                        <div className="flex justify-between items-center mb-1.5">
                            <label className={labelClasses} style={{ marginBottom: 0 }}>Relatório Técnico</label>
                            <VoiceInput onResult={(text) => setFormData(prev => ({ ...prev, relatorioTecnico: (prev.relatorioTecnico ? prev.relatorioTecnico + ' ' : '') + text }))} />
                        </div>
                        <textarea rows="4" value={formData.relatorioTecnico} onChange={e => handleChange('relatorioTecnico', e.target.value)} className={inputClasses} placeholder="Detalhes técnicos da vistoria..." />
                    </div>

                    <div>
                        <div className="flex justify-between items-center mb-1.5">
                            <label className={labelClasses} style={{ marginBottom: 0 }}>Recomendações Imediatas</label>
                            <VoiceInput onResult={(text) => setFormData(prev => ({ ...prev, recomendacoes: (prev.recomendacoes ? prev.recomendacoes + ' ' : '') + text }))} />
                        </div>
                        <textarea rows="2" value={formData.recomendacoes} onChange={e => handleChange('recomendacoes', e.target.value)} className={inputClasses} placeholder="O que o morador/município deve fazer..." />
                    </div>

                    <div className="pt-4 border-t border-gray-100 space-y-4">
                        <div>
                            <label className={labelClasses}>Assinatura do Agente</label>
                            <div
                                onClick={() => {
                                    setActiveSignatureType('agente')
                                    setShowSignaturePad(true)
                                }}
                                className="h-32 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex items-center justify-center cursor-pointer overflow-hidden group hover:border-[#2a5299] transition-colors"
                            >
                                {formData.assinaturaAgente ? (
                                    <img src={formData.assinaturaAgente} className="h-full w-auto object-contain" />
                                ) : (
                                    <div className="text-center">
                                        <Edit2 size={24} className="mx-auto text-slate-300 group-hover:text-[#2a5299]" />
                                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Tocar para Assinar (Agente)</span>
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className="pt-4 border-t border-gray-100">
                            <label className={labelClasses}>Apoio Técnico (Obras/Engenharia)</label>
                            <div className="space-y-3 mb-4">
                                <input
                                    type="text"
                                    placeholder="Nome do Técnico"
                                    className={`${inputClasses} text-sm py-2`}
                                    value={formData.apoioTecnico.nome}
                                    onChange={e => setFormData(prev => ({
                                        ...prev,
                                        apoioTecnico: { ...prev.apoioTecnico, nome: e.target.value }
                                    }))}
                                />
                                <div className="grid grid-cols-2 gap-2">
                                    <input
                                        type="text"
                                        placeholder="CREA/CAU"
                                        className={`${inputClasses} text-sm py-2`}
                                        value={formData.apoioTecnico.crea}
                                        onChange={e => setFormData(prev => ({
                                            ...prev,
                                            apoioTecnico: { ...prev.apoioTecnico, crea: e.target.value }
                                        }))}
                                    />
                                    <input
                                        type="text"
                                        placeholder="Matrícula"
                                        className={`${inputClasses} text-sm py-2`}
                                        value={formData.apoioTecnico.matricula}
                                        onChange={e => setFormData(prev => ({
                                            ...prev,
                                            apoioTecnico: { ...prev.apoioTecnico, matricula: e.target.value }
                                        }))}
                                    />
                                </div>
                            </div>
                            <div
                                onClick={() => {
                                    setActiveSignatureType('apoio')
                                    setShowSignaturePad(true)
                                }}
                                className="h-32 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex items-center justify-center cursor-pointer overflow-hidden group hover:border-[#2a5299] transition-colors"
                            >
                                {formData.apoioTecnico.assinatura ? (
                                    <img src={formData.apoioTecnico.assinatura} className="h-full w-auto object-contain" />
                                ) : (
                                    <div className="text-center">
                                        <Edit2 size={24} className="mx-auto text-slate-300 group-hover:text-[#2a5299]" />
                                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Assinar Apoio Técnico</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </section>

                {/* Submit button */}
                <div className="pt-6">
                    <button
                        type="submit"
                        disabled={saving}
                        className={`w-full p-4 rounded-xl text-white font-bold text-lg shadow-lg flex items-center justify-center gap-3 transition-all active:scale-[0.98] ${saving ? 'bg-slate-400' : 'bg-[#2a5299] hover:bg-[#1e3c72]'}`}
                    >
                        {saving ? (
                            <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        ) : (
                            <><Save size={24} /> Salvar Interdição</>
                        )}
                    </button>

                    <div className="grid grid-cols-2 gap-4 mt-4">
                        <button type="button" onClick={() => generatePDF(formData, 'interdicao')} className="flex justify-center items-center gap-2 p-4 border border-gray-200 rounded-xl font-bold text-gray-600 bg-white hover:bg-gray-50 transition-colors shadow-sm">
                            <Share size={20} /> Exportar PDF
                        </button>
                        {initialData && (
                            <button type="button" onClick={() => alert("Excluir")} className="flex justify-center items-center gap-2 p-4 border border-red-100 text-red-500 bg-red-50/50 rounded-xl font-bold hover:bg-red-100/50 transition-colors">
                                <Trash2 size={20} /> Excluir
                            </button>
                        )}
                    </div>
                </div>

            </form>

            {/* Signature Modal */}
            {showSignaturePad && (
                <SignaturePadComp
                    title={activeSignatureType === 'agente' ? "Assinatura do Agente" : "Assinatura do Apoio Técnico"}
                    onCancel={() => setShowSignaturePad(false)}
                    onSave={(dataUrl) => {
                        if (activeSignatureType === 'agente') {
                            setFormData(prev => ({ ...prev, assinaturaAgente: dataUrl }))
                        } else {
                            setFormData(prev => ({
                                ...prev,
                                apoioTecnico: { ...prev.apoioTecnico, assinatura: dataUrl }
                            }))
                        }
                        setShowSignaturePad(false)
                    }}
                />
            )}
        </div>
    )
}

export default InterdicaoForm

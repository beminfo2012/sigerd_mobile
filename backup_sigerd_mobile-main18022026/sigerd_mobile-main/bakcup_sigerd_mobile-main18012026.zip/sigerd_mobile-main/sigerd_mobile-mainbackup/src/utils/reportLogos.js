
import logoDefesaCivil from '../assets/logo_defesa_civil.png';
import logoSigerd from '../assets/logo_sigerd.png';

export const LOGO_DEFESA_CIVIL = logoDefesaCivil;
export const LOGO_SIGERD = logoSigerd;
